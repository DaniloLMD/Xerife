#ifndef CASDASTRO_LISTA
#define CASDASTRO_LISTA
#include "includes.h"

void casdastrar_lista(const char* nome, const char* qtd_entradasaida, const char* qtdquestao);



#endif