#ifndef XEREFI_H
#define XEREFI_H

#include "../cadastro/cadastro.h"
#include "../includes.h"
#include "../login/login.h"
void on_bt_submeter_pagina_questao_clicked ();

void on_bt_voltar_cadastro_clicked ();

void mensagem (const char *texto, const char *texto_secundario);

void on_bt_enviar_cadastro_clicked ();

void on_bt_login_tela_login_clicked ();

void on_bt_cadastre_se_login_clicked ();



#endif