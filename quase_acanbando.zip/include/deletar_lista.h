#ifndef __DELETAR_LISTA_H__
#define __DELETAR_LISTA_H__

bool deletar_lista(int n_lista);

int get_qtd_listas();

char* set_nome_lista(int n_lista, char* list_name);

#endif