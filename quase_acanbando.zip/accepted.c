#include <stdio.h>
//#include <math.h>

int main () 
{ 
    printf("Hello, World!");
    return 0;
}