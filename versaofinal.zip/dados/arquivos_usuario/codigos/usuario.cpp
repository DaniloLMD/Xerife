#include <bits/stdc++.h>

using namespace std;

int main(){

	int a, b;

	std::cin >> a >> b;

	std::cout << a+b << std::endl;
	
	return 0;
}