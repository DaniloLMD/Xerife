#ifndef includes_h
#define includes_h

#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "lista.h"
#include "paths.h"
#endif