#include <stdio.h>

int main(){
    long long int luis = 1;
    while(luis--){
        //printf("luis = %lld\n", luis);
    }

    return 0;
}