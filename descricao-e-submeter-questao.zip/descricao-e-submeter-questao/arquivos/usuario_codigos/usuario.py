a = float(input())
b = float(input())
c = a/b

print(f"{c:.{2}f}")