#include <stdio.h>

int main(){
    int a, b;
    

    scanf("%d %d", &a, &b);

    if(a == -1){
        while(1){

        }
    }

    printf("%d.00\n",  a/b);
    
    return 0;
}