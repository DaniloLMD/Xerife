#ifndef CASDASTRO_LISTA
#define CASDASTRO_LISTA
#include "includes.h"

void casdastrar_lista(const char*, const char*);



#endif