#ifndef __lista_c__
#define __lista_c__

typedef struct {
    int numero_da_lista;
    int qtd_entrada_saida;
} lista;

#endif