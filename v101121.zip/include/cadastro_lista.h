#ifndef CASDASTRO_LISTA
#define CASDASTRO_LISTA
#include "includes.h"

void casdastrar_lista(const char* nome, const char* qtd_entradasaida, const char* qtdquestao);
int verificacoes_nome_lista(const char* nome);
bool contem_apenas_numeros(const char *stringx);

#endif