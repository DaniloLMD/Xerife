#ifndef __lista_c__
#define __lista_c__

typedef struct {
    int numero_da_lista;
    int qtd_entrada_saida;
    int quantidade_de_questoes;

    //numero da questao atual
    int numero_da_questao;
} llista;

#endif